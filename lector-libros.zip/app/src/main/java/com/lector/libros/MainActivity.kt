package com.lector.libros

import android.Manifest
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.flow.update
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LectorTheme { Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { App() } } }
    }
}

@Composable
fun LectorTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF5FA88A), onPrimary = Color.White,
            primaryContainer = Color(0xFFCDEBDD), onPrimaryContainer = Color(0xFF1F4D3A),
            secondary = Color(0xFFE9A98B), secondaryContainer = Color(0xFFFBE3D0), onSecondaryContainer = Color(0xFF5A3420),
            background = Color(0xFFFFF8E7), onBackground = Color(0xFF3B3A36),
            surface = Color(0xFFFFFCF2), onSurface = Color(0xFF3B3A36),
            surfaceVariant = Color(0xFFF1EAD8), onSurfaceVariant = Color(0xFF5C584D),
            outline = Color(0xFFB8B09A)
        ),
        content = content
    )
}

private val covers = listOf(0xFFF8D9C8, 0xFFCDEBDD, 0xFFFBEBB5, 0xFFDDD5F0, 0xFFCFE4F5, 0xFFF5D0DA).map { Color(it) }

@Composable
fun App(vm: MainViewModel = viewModel()) {
    val ctx = LocalContext.current
    val books by vm.books.collectAsState()
    val scanning by vm.scanning.collectAsState()
    val message by vm.message.collectAsState()
    val ui by ReaderState.flow.collectAsState()
    var reading by remember { mutableStateOf(false) }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    val pickFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u ->
        if (u != null) vm.addFolder(u)
    }
    val pickBooks = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { l ->
        vm.addBooks(l)
    }
    if (reading) {
        BackHandler { reading = false }
        ReaderScreen(ui) { reading = false }
    } else {
        Column(Modifier.fillMaxSize().padding(16.dp)) {
            Text("Mi biblioteca", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Row(Modifier.padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { pickFolder.launch(null) }) { Text("Elegir carpeta") }
                OutlinedButton(onClick = { pickBooks.launch(arrayOf("*/*")) }) { Text("Agregar libros") }
            }
            if (scanning) Text("Buscando libros…", color = MaterialTheme.colorScheme.onSurfaceVariant)
            message?.let { Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            if (books.isEmpty() && !scanning) {
                Text(
                    "Todavía no hay libros. Elegí una carpeta con tus libros (por ejemplo Documentos/Libros) o agregá archivos EPUB, PDF o TXT uno por uno.",
                    Modifier.padding(top = 12.dp)
                )
            }
            LazyVerticalGrid(
                columns = GridCells.Adaptive(150.dp),
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(books, key = { it.uri }) { b ->
                    Card(
                        Modifier.fillMaxWidth().clickable { vm.open(b); reading = true },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Box(
                            Modifier.fillMaxWidth().aspectRatio(0.75f)
                                .background(covers[(b.name.hashCode() and 0x7fffffff) % covers.size]),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(b.title.take(1).uppercase(), fontSize = 56.sp, fontWeight = FontWeight.Bold,
                                color = Color(0xFF4A4A44))
                            Text(b.ext.uppercase(), Modifier.align(Alignment.TopEnd).padding(8.dp), fontSize = 11.sp,
                                color = Color(0xFF4A4A44))
                        }
                        Text(b.title, Modifier.padding(10.dp), maxLines = 3, overflow = TextOverflow.Ellipsis,
                            fontWeight = FontWeight.Medium)
                    }
                }
            }
            if (ui.chunks.isNotEmpty()) {
                Card(
                    Modifier.fillMaxWidth().padding(top = 10.dp).clickable { reading = true },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Text((if (ui.playing) "Leyendo: " else "Continuar: ") + ui.title, Modifier.padding(14.dp),
                        maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }
        }
    }
}

private fun seek(ctx: Context, ui: ReaderUi, i: Int) {
    ReaderState.flow.update { it.copy(index = i) }
    Prefs.savePos(ctx, ui.bookId, i)
    if (ui.playing) sendCmd(ctx, ReaderService.SEEK, i = i)
}

@Composable
fun ReaderScreen(ui: ReaderUi, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val list = rememberLazyListState()
    var drag by remember { mutableStateOf<Float?>(null) }
    LaunchedEffect(ui.index, ui.chunks.size) {
        if (ui.chunks.isNotEmpty()) list.animateScrollToItem(ui.index.coerceIn(0, ui.chunks.size - 1))
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 8.dp)) {
        TextButton(onClick = onBack) { Text("← Biblioteca") }
        Text(ui.title, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Box(Modifier.weight(1f).fillMaxWidth().padding(vertical = 8.dp)) {
            when {
                ui.loading -> Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
                    CircularProgressIndicator(); Text("Preparando el libro…", Modifier.padding(top = 12.dp))
                }
                ui.chunks.isEmpty() -> Text(ui.error ?: "Sin contenido")
                else -> LazyColumn(state = list, modifier = Modifier.fillMaxSize()) {
                    itemsIndexed(ui.chunks) { i, t ->
                        Text(
                            t,
                            Modifier.fillMaxWidth().padding(vertical = 3.dp).clip(RoundedCornerShape(10.dp))
                                .background(if (i == ui.index) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                                .clickable { seek(ctx, ui, i) }.padding(10.dp),
                            fontSize = 18.sp, lineHeight = 26.sp
                        )
                    }
                }
            }
        }
        if (ui.error != null && ui.chunks.isNotEmpty()) Text(ui.error, color = MaterialTheme.colorScheme.error)
        if (ui.needsVoice) {
            Button(onClick = {
                try { ctx.startActivity(Intent("com.android.settings.TTS_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                catch (e: Exception) { ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            }) { Text("Abrir ajustes de voz") }
        }
        if (ui.chunks.isNotEmpty()) {
            val max = maxOf(1, ui.chunks.size - 1).toFloat()
            Slider(
                value = drag ?: ui.index.toFloat(),
                onValueChange = { drag = it },
                valueRange = 0f..max,
                onValueChangeFinished = { drag?.let { seek(ctx, ui, it.roundToInt()) }; drag = null }
            )
            Text("${(ui.index * 100 / ui.chunks.size)}% leído", Modifier.fillMaxWidth(), textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = { sendCmd(ctx, if (ui.playing) ReaderService.PAUSE else ReaderService.PLAY) },
                    modifier = Modifier.weight(1f).height(72.dp)
                ) { Text(if (ui.playing) "⏸  Pausar" else "▶  Reproducir", fontSize = 22.sp) }
                OutlinedButton(onClick = { sendCmd(ctx, ReaderService.STOP) }, Modifier.height(72.dp)) {
                    Text("⏹ Detener", fontSize = 16.sp)
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { setRate(ctx, ui, ui.rate - 0.1f) }) { Text("−", fontSize = 22.sp) }
                Text("Velocidad %.1fx".format(ui.rate), Modifier.padding(horizontal = 16.dp), fontSize = 18.sp)
                OutlinedButton(onClick = { setRate(ctx, ui, ui.rate + 0.1f) }) { Text("+", fontSize = 22.sp) }
            }
        }
    }
}

private fun setRate(ctx: Context, ui: ReaderUi, r: Float) {
    val v = ((r.coerceIn(0.5f, 2.0f)) * 10).roundToInt() / 10f
    ReaderState.flow.update { it.copy(rate = v) }
    Prefs.saveRate(ctx, v)
    if (ui.playing) sendCmd(ctx, ReaderService.RATE, r = v)
}
