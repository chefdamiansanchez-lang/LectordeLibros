package com.lector.libros

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.IBinder
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.session.PlaybackStateCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.media.app.NotificationCompat.MediaStyle
import kotlinx.coroutines.flow.update
import java.util.Locale

fun sendCmd(c: Context, action: String, i: Int = -1, r: Float = 0f) {
    val intent = Intent(c, ReaderService::class.java).setAction(action)
    if (i >= 0) intent.putExtra("i", i)
    if (r > 0f) intent.putExtra("r", r)
    ContextCompat.startForegroundService(c, intent)
}

class ReaderService : Service() {
    companion object {
        const val PLAY = "lector.PLAY"
        const val PAUSE = "lector.PAUSE"
        const val STOP = "lector.STOP"
        const val SEEK = "lector.SEEK"
        const val RATE = "lector.RATE"
        private const val CH = "lectura"
        private const val NID = 7
    }

    private var tts: TextToSpeech? = null
    private var ready = false
    private var wantPlay = false
    private var dead = false
    private var queuedUntil = 0
    private lateinit var session: MediaSessionCompat
    private lateinit var audio: AudioManager
    private var wake: PowerManager.WakeLock? = null
    private val attrs = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(NotificationChannel(CH, "Lectura en voz alta", NotificationManager.IMPORTANCE_LOW))
        wake = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "lector:tts")
        wake?.setReferenceCounted(false)
        session = MediaSessionCompat(this, "LectorLibros")
        session.setCallback(object : MediaSessionCompat.Callback() {
            override fun onPlay() { play() }
            override fun onPause() { pause() }
            override fun onStop() { stopAll() }
        })
        session.isActive = true
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS && pickSpanish()) {
                ready = true
                tts?.setAudioAttributes(attrs)
                tts?.setOnUtteranceProgressListener(listener)
                if (wantPlay) speakFrom(ReaderState.flow.value.index)
            } else {
                ReaderState.flow.update {
                    it.copy(playing = false, needsVoice = true,
                        error = "Falta la voz en español. Instalá o activá la voz de Google en español en los ajustes de texto a voz.")
                }
                stopAll()
            }
        }
    }

    private fun pickSpanish(): Boolean {
        val t = tts ?: return false
        val options = listOf(Locale("es", "AR"), Locale("es", "MX"), Locale("es", "US"), Locale("es", "ES"), Locale("es"))
        for (l in options) {
            if (t.isLanguageAvailable(l) >= TextToSpeech.LANG_AVAILABLE) {
                t.setLanguage(l)
                return true
            }
        }
        return false
    }

    private val listener = object : UtteranceProgressListener() {
        override fun onStart(utteranceId: String?) {
            val i = utteranceId?.removePrefix("c")?.toIntOrNull() ?: return
            ReaderState.flow.update { it.copy(index = i) }
            Prefs.savePos(applicationContext, ReaderState.flow.value.bookId, i)
            enqueue(i + 4)
            refresh()
        }
        override fun onDone(utteranceId: String?) {
            val i = utteranceId?.removePrefix("c")?.toIntOrNull() ?: return
            val s = ReaderState.flow.value
            if (s.playing && i >= s.chunks.size - 1) {
                Prefs.savePos(applicationContext, s.bookId, 0)
                ReaderState.flow.update { it.copy(index = 0) }
                stopAll()
            }
        }
        @Deprecated("Deprecated in Java")
        override fun onError(utteranceId: String?) {}
    }

    private fun enqueue(limit: Int) {
        val t = tts ?: return
        val ch = ReaderState.flow.value.chunks
        val end = minOf(limit, ch.size)
        while (queuedUntil < end) {
            t.speak(ch[queuedUntil], TextToSpeech.QUEUE_ADD, null, "c$queuedUntil")
            queuedUntil++
        }
    }

    private fun speakFrom(i: Int) {
        val t = tts ?: return
        if (!ready) { wantPlay = true; return }
        t.stop()
        t.setSpeechRate(ReaderState.flow.value.rate)
        queuedUntil = i
        enqueue(i + 4)
    }

    private fun requestFocus() {
        val r = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
            .setAudioAttributes(attrs)
            .setOnAudioFocusChangeListener { c ->
                if (c == AudioManager.AUDIOFOCUS_LOSS || c == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) pause()
            }.build()
        audio.requestAudioFocus(r)
    }

    private fun play() {
        val s = ReaderState.flow.value
        if (s.chunks.isEmpty()) { stopAll(); return }
        requestFocus()
        wantPlay = true
        ReaderState.flow.update { it.copy(playing = true, error = null, needsVoice = false) }
        wake?.acquire(6 * 3600 * 1000L)
        speakFrom(s.index)
        refresh()
    }

    private fun pause() {
        wantPlay = false
        tts?.stop()
        ReaderState.flow.update { it.copy(playing = false) }
        if (wake?.isHeld == true) wake?.release()
        refresh()
    }

    private fun stopAll() {
        dead = true
        wantPlay = false
        tts?.stop()
        ReaderState.flow.update { it.copy(playing = false) }
        if (wake?.isHeld == true) wake?.release()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        dead = false
        ServiceCompat.startForeground(this, NID, buildNotif(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        if (ReaderState.flow.value.chunks.isEmpty()) { stopAll(); return START_NOT_STICKY }
        when (intent?.action) {
            PLAY -> play()
            PAUSE -> pause()
            STOP -> stopAll()
            SEEK -> {
                val i = intent.getIntExtra("i", 0)
                ReaderState.flow.update { it.copy(index = i) }
                Prefs.savePos(applicationContext, ReaderState.flow.value.bookId, i)
                if (ReaderState.flow.value.playing) speakFrom(i)
                refresh()
            }
            RATE -> {
                val r = intent.getFloatExtra("r", 1f)
                ReaderState.flow.update { it.copy(rate = r) }
                Prefs.saveRate(applicationContext, r)
                if (ReaderState.flow.value.playing) speakFrom(ReaderState.flow.value.index)
            }
        }
        return START_NOT_STICKY
    }

    private fun buildNotif(): Notification {
        val s = ReaderState.flow.value
        fun pi(a: String, n: Int) = PendingIntent.getService(
            this, n, Intent(this, ReaderService::class.java).setAction(a),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val b = NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat_book)
            .setContentTitle(s.title.ifEmpty { "Lector de libros" })
            .setContentText(s.chunks.getOrNull(s.index) ?: "")
            .setContentIntent(open)
            .setOnlyAlertOnce(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
        if (s.playing) b.addAction(android.R.drawable.ic_media_pause, "Pausar", pi(PAUSE, 1))
        else b.addAction(android.R.drawable.ic_media_play, "Reproducir", pi(PLAY, 2))
        b.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Detener", pi(STOP, 3))
        b.setStyle(MediaStyle().setMediaSession(session.sessionToken).setShowActionsInCompactView(0, 1))
        return b.build()
    }

    private fun refresh() {
        if (dead) return
        val s = ReaderState.flow.value
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NID, buildNotif())
        session.setPlaybackState(
            PlaybackStateCompat.Builder()
                .setActions(PlaybackStateCompat.ACTION_PLAY or PlaybackStateCompat.ACTION_PAUSE or
                    PlaybackStateCompat.ACTION_PLAY_PAUSE or PlaybackStateCompat.ACTION_STOP)
                .setState(if (s.playing) PlaybackStateCompat.STATE_PLAYING else PlaybackStateCompat.STATE_PAUSED,
                    s.index.toLong(), 1f)
                .build())
    }

    override fun onDestroy() {
        dead = true
        tts?.stop(); tts?.shutdown()
        session.release()
        if (wake?.isHeld == true) wake?.release()
        super.onDestroy()
    }
}
