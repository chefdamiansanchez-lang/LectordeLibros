package com.lector.libros

import android.content.Context
import android.net.Uri
import android.text.Html
import android.util.Xml
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream
import java.util.zip.ZipInputStream

object BookLoader {
    fun load(c: Context, b: Book): String {
        val input = c.contentResolver.openInputStream(Uri.parse(b.uri)) ?: error("No se pudo abrir el archivo")
        return input.use {
            when (b.ext) {
                "txt" -> it.readBytes().toString(Charsets.UTF_8)
                "pdf" -> {
                    PDFBoxResourceLoader.init(c.applicationContext)
                    PDDocument.load(it).use { d -> PDFTextStripper().getText(d) }
                }
                "epub" -> epub(it)
                else -> error("Formato no soportado (usá EPUB, PDF o TXT)")
            }
        }
    }

    private fun epub(input: InputStream): String {
        val files = HashMap<String, ByteArray>()
        ZipInputStream(input).use { z ->
            var e = z.nextEntry
            while (e != null) {
                val n = e.name.lowercase()
                if (!e.isDirectory && (n.endsWith(".xml") || n.endsWith(".opf") || n.endsWith("html") || n.endsWith(".htm"))) {
                    files[e.name] = z.readBytes()
                }
                e = z.nextEntry
            }
        }
        val container = files["META-INF/container.xml"]?.toString(Charsets.UTF_8) ?: error("EPUB inválido")
        val opfPath = Regex("full-path=\"([^\"]+)\"").find(container)?.groupValues?.get(1) ?: error("EPUB inválido")
        val opf = files[opfPath] ?: error("EPUB inválido")
        val dir = opfPath.substringBeforeLast('/', "")
        val manifest = HashMap<String, String>()
        val spine = ArrayList<String>()
        val p = Xml.newPullParser()
        p.setInput(opf.inputStream(), null)
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                if (p.name == "item") manifest[p.getAttributeValue(null, "id") ?: ""] = p.getAttributeValue(null, "href") ?: ""
                else if (p.name == "itemref") spine.add(p.getAttributeValue(null, "idref") ?: "")
            }
            ev = p.next()
        }
        val sb = StringBuilder()
        for (id in spine) {
            val href = Uri.decode(manifest[id] ?: continue).substringBefore('#')
            val bytes = files[normalize(if (dir.isEmpty()) href else "$dir/$href")] ?: continue
            sb.append(htmlToText(bytes.toString(Charsets.UTF_8))).append("\n\n")
        }
        return sb.toString()
    }

    private fun htmlToText(html: String): String {
        val h = html.replace(Regex("(?is)<head[^>]*>.*?</head>"), "")
            .replace(Regex("(?is)<(script|style)[^>]*>.*?</\\1>"), "")
        return Html.fromHtml(h, Html.FROM_HTML_MODE_LEGACY).toString().replace('\uFFFC', ' ')
    }

    private fun normalize(p: String): String {
        val out = ArrayList<String>()
        for (s in p.split('/')) {
            if (s == "..") { if (out.isNotEmpty()) out.removeAt(out.size - 1) }
            else if (s != "." && s.isNotEmpty()) out.add(s)
        }
        return out.joinToString("/")
    }
}

object TextChunker {
    private val sentence = Regex("""(?<=[.!?…»”])\s+""")
    fun chunk(text: String, maxLen: Int = 320): List<String> {
        val out = ArrayList<String>()
        for (para in text.replace("\u00AD", "").split(Regex("\\n+"))) {
            val p = para.replace(Regex("\\s+"), " ").trim()
            if (p.isEmpty()) continue
            val sb = StringBuilder()
            for (raw in p.split(sentence)) {
                var s = raw.trim()
                if (s.isEmpty()) continue
                while (s.length > maxLen) {
                    var cut = s.lastIndexOf(' ', maxLen)
                    if (cut < maxLen / 2) cut = maxLen
                    if (sb.isNotEmpty()) { out.add(sb.toString()); sb.clear() }
                    out.add(s.substring(0, cut).trim())
                    s = s.substring(cut).trim()
                }
                if (s.isEmpty()) continue
                if (sb.length + s.length + 1 > maxLen && sb.isNotEmpty()) { out.add(sb.toString()); sb.clear() }
                if (sb.isNotEmpty()) sb.append(' ')
                sb.append(s)
            }
            if (sb.isNotEmpty()) out.add(sb.toString())
        }
        return out
    }
}
