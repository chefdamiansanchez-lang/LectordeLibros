package com.lector.libros

import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx: Application get() = getApplication()
    private val exts = setOf("epub", "pdf", "txt")
    val books = MutableStateFlow<List<Book>>(emptyList())
    val scanning = MutableStateFlow(false)
    val message = MutableStateFlow<String?>(null)

    init { refresh() }

    fun refresh() {
        viewModelScope.launch(Dispatchers.IO) {
            scanning.value = true
            val all = LinkedHashMap<String, Book>()
            Prefs.books(ctx).forEach { all[it.uri] = it }
            for (f in Prefs.folders(ctx)) {
                try { DocumentFile.fromTreeUri(ctx, Uri.parse(f))?.let { scan(it, 0, all) } } catch (_: Exception) {}
            }
            books.value = all.values.sortedBy { it.title.lowercase() }
            scanning.value = false
        }
    }

    private fun scan(d: DocumentFile, depth: Int, out: MutableMap<String, Book>) {
        if (depth > 4) return
        for (f in d.listFiles()) {
            if (f.isDirectory) scan(f, depth + 1, out)
            else {
                val n = f.name ?: continue
                if (n.substringAfterLast('.', "").lowercase() in exts) out[f.uri.toString()] = Book(f.uri.toString(), n)
            }
        }
    }

    fun addFolder(uri: Uri) {
        try { ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        Prefs.addFolder(ctx, uri.toString())
        refresh()
    }

    fun addBooks(uris: List<Uri>) {
        var bad = 0
        for (u in uris) {
            try { ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            val name = DocumentFile.fromSingleUri(ctx, u)?.name ?: u.lastPathSegment ?: "libro"
            if (name.substringAfterLast('.', "").lowercase() in exts) Prefs.addBook(ctx, Book(u.toString(), name)) else bad++
        }
        message.value = if (bad > 0) "$bad archivo(s) ignorado(s): solo EPUB, PDF o TXT" else null
        refresh()
    }

    fun open(b: Book) {
        val cur = ReaderState.flow.value
        if (cur.bookId == b.uri && cur.chunks.isNotEmpty()) return
        if (cur.playing) sendCmd(ctx, ReaderService.STOP)
        ReaderState.flow.value = ReaderUi(bookId = b.uri, title = b.title, loading = true, rate = Prefs.rate(ctx))
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val chunks = TextChunker.chunk(BookLoader.load(ctx, b))
                if (chunks.isEmpty()) error("No se encontró texto legible (¿es un PDF escaneado?)")
                val start = Prefs.pos(ctx, b.uri).coerceIn(0, chunks.size - 1)
                ReaderState.flow.update { it.copy(chunks = chunks, index = start, loading = false) }
            } catch (e: Throwable) {
                ReaderState.flow.update { it.copy(loading = false, error = e.message ?: "No se pudo abrir el libro") }
            }
        }
    }
}
