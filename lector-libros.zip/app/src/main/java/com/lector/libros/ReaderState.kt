package com.lector.libros

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow

data class Book(val uri: String, val name: String) {
    val ext: String get() = name.substringAfterLast('.', "").lowercase()
    val title: String get() = name.substringBeforeLast('.')
}

data class ReaderUi(
    val bookId: String = "",
    val title: String = "",
    val chunks: List<String> = emptyList(),
    val index: Int = 0,
    val playing: Boolean = false,
    val rate: Float = 1f,
    val loading: Boolean = false,
    val error: String? = null,
    val needsVoice: Boolean = false
)

object ReaderState { val flow = MutableStateFlow(ReaderUi()) }

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("lector", Context.MODE_PRIVATE)
    fun books(c: Context): List<Book> =
        (sp(c).getStringSet("books", emptySet()) ?: emptySet()).mapNotNull { s ->
            val p = s.split("\t"); if (p.size == 2) Book(p[0], p[1]) else null
        }
    fun addBook(c: Context, b: Book) {
        val s = HashSet(sp(c).getStringSet("books", emptySet()) ?: emptySet())
        s.add(b.uri + "\t" + b.name); sp(c).edit().putStringSet("books", s).apply()
    }
    fun folders(c: Context): Set<String> = HashSet(sp(c).getStringSet("folders", emptySet()) ?: emptySet())
    fun addFolder(c: Context, u: String) {
        val s = HashSet(folders(c)); s.add(u); sp(c).edit().putStringSet("folders", s).apply()
    }
    fun pos(c: Context, id: String): Int = sp(c).getInt("pos_" + id.hashCode(), 0)
    fun savePos(c: Context, id: String, i: Int) { sp(c).edit().putInt("pos_" + id.hashCode(), i).apply() }
    fun rate(c: Context): Float = sp(c).getFloat("rate", 1f)
    fun saveRate(c: Context, r: Float) { sp(c).edit().putFloat("rate", r).apply() }
}
